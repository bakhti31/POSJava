
package tugasakhir; // mengidentifikasikan berada didalam package tugasakhir

public final class TugasAkhir { // Class
   
    public static final Home hm=new Home(); // memanggil class lain
    public static final DataCore dt=new DataCore(); // memanggil class lain
    
    public static void main(String[] args) {
        // TODO code application logic here
        //Mensetting agar semua kelas dapat terhubung
        hm.setVisible(true); 
        hm.pack();
        hm.setLocationRelativeTo(null);
        hm.setDefaultCloseOperation(Home.EXIT_ON_CLOSE);
        
        dt.setVisible(true);
        dt.pack();
        dt.setLocationRelativeTo(null);
        dt.setDefaultCloseOperation(DataCore.EXIT_ON_CLOSE);
        dt.setState(1);//Minimize Class DataCore
        
    }
    
}

