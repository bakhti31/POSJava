
package tugasakhir; //Mengindentifikasi didalam package tugasakhir

import java.util.regex.Pattern;//Ini contoh menggunakan sebuah package

/**
 *
 * @author bakhti
 */
abstract class fungsi{ // Class Abstract
    abstract void buat(Object[] o); // Abstract Method
    abstract Object baca(int row, int col); //Abstract Method
    abstract void perbarui(Object s, int row, int col);//Abstract Method
    abstract void hapus(int id);//Abstract Method
}

public class Fungsional extends fungsi{ // Class Inhertance
    //yang ada dibawah ini adalah variable
    private javax.swing.table.DefaultTableModel model; //
    private javax.swing.table.DefaultTableModel other;
    
    //yang ada dibawah ini adalah method
    
    /**
     * saat class dipanggil, class dapat berjalan walaupun tanpa parameter
     */
    public Fungsional(){//Constructor 
        //Contoh dari Constructor kosong
    }
    
    /**
     * saat class dipanggil langsung diikuti table model utama
     * @param tabl parameter untuk menambahkan table model
     */
    public Fungsional(javax.swing.table.DefaultTableModel tabl){//Constructor Parameter
        this.model = tabl;
    }
    
    /**
     * menambahkan table model utama
     * @param tabl tablemodel utama
     */
    public void setTabl(javax.swing.table.DefaultTableModel tabl){ // Method Setter
        this.model = tabl;
    }
    
    /**
     * menambahkan tablemodel utama dan kedua
     * @param tabl tablemodel utama
     * @param tables tablemodel kedua
     * digunakan jika akan ada pencarian dari table lainnya
     */
    public void setTabl(javax.swing.table.DefaultTableModel tabl,javax.swing.table.DefaultTableModel tables){ //Method dual setter
        this.model = tabl;
        this.other = tables;
    }
    
    /**
     * menghitung jumlah baris table model utama
     * @return integer
     */
    public int rowcount(){//Method
        return this.model.getRowCount();
    }
    
    public int rowcount(boolean other){//Method Overloading
        return this.other.getRowCount();
    }
    
    /**
     *  menghapus baris didalam table
     * @param id baris yang ingin dihapus
     */
    @Override
    public void hapus(int id){//Method Overriding with Parameter
        model.removeRow(id);
    }
    
    /**
     * menambahkan baris
     * @param a objek array 1 dimensi
     */
    @Override
    public void buat(Object[] a){//Method Overriding with Parameter
        model.addRow(a); //Menambahkan Baris
    }
    
    /**
     * mengembalikan tablemodel
     * @return tablemodel
     */
    public javax.swing.table.DefaultTableModel model(){ // Method Getter
        return this.model;
    }
    
    /**
     * mencari Baris yang mengandung kata yang ingin dicari
     * @param query kata yang akan dicari
     * @param col berada dikolom berapakan kata tersebut
     * @return kembaliannya berupa angka, jika tidak ada hasil akan mengembalikan nol
     */
    public int caribaris(String query, int col){ //Method Parameter
        for (int k = 0; k < model.getRowCount(); k++) {
            if(Pattern.matches(".*"+query+".*", (String)model.getValueAt(k, col))){
                return k;
            }
        }
        return 0;
    }
    
    /**
     * mencari Baris yang mengandung kata yang ingin dicari
     * @param query kata yang akan dicari
     * @param col berada dikolom berapakan kata tersebut
     * @param others bersifat boolean untuk menggunakan tablemodel lainnya
     * @return kembaliannya berupa angka, jika tidak ada hasil akan mengembalikan nol
     */
    public int caribaris(String query, int col, boolean others){ // Method Parameter
        for (int k = 0; k < other.getRowCount(); k++) {
            if(Pattern.matches(".*"+query+".*", (String)other.getValueAt(k, col))){
                return k;
            }
        }
        return 0;
    }
    
    /**
     * Membaca Isi Kolom
     * @param row baris yang akan dibaca katanya
     * @param col kolom yang akan dibaca katanya
     * @return kembaliannya berupa object
     */
    @Override
    public Object baca(int row,int col){
        return model.getValueAt(row, col);
    }
    
    /**
     * Membaca isi kolom
     * @param row baris yang akan dibaca katanya
     * @param col kolom yang akan dibaca katanya
     * @param others menggunakan tablemodel kedua
     * @return object
     */
    public Object baca(int row, int col, boolean others){
        return other.getValueAt(row, col);
    }
    
    
    /**
     *
     * @param obj objek
     * @param row baris yang mau diubah
     * @param col kolom yang mau diubah
     */
    @Override
    public void perbarui(Object obj, int row, int col){
        model.setValueAt(obj, row, col);
    }
    
    /**
     *
     * @param obj objek
     * @param row baris yang mau diubah
     * @param col kolom yang mau diubah
     * @param others menggunakan tablemodel kedua
     */
    public void perbarui(Object obj, int row, int col, boolean others){
        other.setValueAt(obj, row, col);
    }
    
    /**
     *
     * @param query yang ingin dicari
     * @param Col berada dikolom ke berapa
     * @return object yang dipilih
     */
    public Object Search(String query,int Col){
        int find = caribaris(query,0);
        return baca(find,Col);
    }
    
    /**
     *
     * @param query kata yang ingin dicari
     * @param Col dikolom berapa kata tersebut
     * @param others menggunakan table kedua
     * @return objek yang dipilih
     */
    public Object Search(String query,int Col,boolean others){
        int find = caribaris(query, 0,others);
        return baca(find, Col,others);
    }
    
}
