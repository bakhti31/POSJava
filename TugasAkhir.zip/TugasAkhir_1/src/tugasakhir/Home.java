
package tugasakhir; // Mengidentifikasikan berada dalam Package tugasakhir

import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;//Library autocomplete combobox

public class Home extends javax.swing.JFrame{ 
        
    public Home() { // Constructor
        initComponents();
        AutoCompleteDecorator.decorate(jComboBox1); // Fungsinya Untuk Meneyelesaikan Secara Otomatis Nama Barang
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        billprint = new javax.swing.JTextArea();
        jDialog2 = new javax.swing.JDialog();
        jScrollPane3 = new javax.swing.JScrollPane();
        Warn = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Total = new javax.swing.JTextField();
        Jumlah = new javax.swing.JTextField();
        Tambah = new javax.swing.JButton();
        Bersih = new javax.swing.JButton();
        Lihat = new javax.swing.JButton();
        Ubah = new javax.swing.JButton();
        OK = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        Bayar = new javax.swing.JTextField();
        Hapus = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane(Tabl);
        Tabl = new javax.swing.JTable();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();

        jDialog1.setSize(new java.awt.Dimension(320, 480));

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Toko Bernilai");

        billprint.setEditable(false);
        billprint.setColumns(20);
        billprint.setRows(5);
        billprint.setText(" ====================================\nDetail\nNama Barang\nQTY x Price\t\tSum\n\n------------------------------------------------\n\t\tAll Sum\n\n\n\n========                  Thanks                 =========");
        jScrollPane2.setViewportView(billprint);

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jDialog1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 296, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDialog1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 426, Short.MAX_VALUE)
                .addContainerGap())
        );

        jDialog2.setSize(new java.awt.Dimension(320, 140));

        Warn.setEditable(false);
        Warn.setColumns(20);
        Warn.setRows(5);
        jScrollPane3.setViewportView(Warn);

        javax.swing.GroupLayout jDialog2Layout = new javax.swing.GroupLayout(jDialog2.getContentPane());
        jDialog2.getContentPane().setLayout(jDialog2Layout);
        jDialog2Layout.setHorizontalGroup(
            jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDialog2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 296, Short.MAX_VALUE)
                .addContainerGap())
        );
        jDialog2Layout.setVerticalGroup(
            jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDialog2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(340, 480));
        setSize(new java.awt.Dimension(340, 480));

        jLabel1.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Toko Bernilai");

        jLabel2.setText("Nama Barang");

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Total");

        jLabel4.setText("Jumlah Barang");

        Tambah.setText("Tambah");
        Tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TambahActionPerformed(evt);
            }
        });

        Bersih.setText("Bersihkan");
        Bersih.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BersihActionPerformed(evt);
            }
        });

        Lihat.setText("Data");
        Lihat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LihatActionPerformed(evt);
            }
        });

        Ubah.setText("Ubah");
        Ubah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UbahActionPerformed(evt);
            }
        });

        OK.setText("OK");
        OK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OKActionPerformed(evt);
            }
        });

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Bayar");

        Hapus.setText("Hapus");
        Hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HapusActionPerformed(evt);
            }
        });

        Tabl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nama", "Harga", "Jumlah", "Total"
            }
        ));
        Tabl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TablMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Tabl);

        jComboBox1.setEditable(true);
        jComboBox1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jComboBox1FocusGained(evt);
            }
        });
        jComboBox1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jComboBox1MousePressed(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jComboBox1MouseClicked(evt);
            }
        });
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel7.setText("User");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 73, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Total, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Bayar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Tambah)
                        .addGap(56, 56, 56)
                        .addComponent(Hapus)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Ubah))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Bersih)
                        .addGap(40, 40, 40)
                        .addComponent(OK, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(Lihat))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jComboBox1, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Jumlah))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Jumlah, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Tambah)
                    .addComponent(Ubah)
                    .addComponent(Hapus))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Total, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(Bayar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(OK)
                    .addComponent(Lihat)
                    .addComponent(Bersih))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    final class func extends Fungsional{// Final Class, Inheritance dari class Fungsional
        public func(){ //Constructor
            DataCore dt=TugasAkhir.dt; 
            setTabl((javax.swing.table.DefaultTableModel) Tabl.getModel(),(javax.swing.table.DefaultTableModel) dt.Tables.getModel());
        }
        
        public void clear(){
            //Untuk menghapus seluruh isi table
            if (rowcount()>0) {
                for (int i = 0; i < rowcount(); i++) {
                    hapus(i);
                }
            }
        }
        
        public void printbill(){
            //Fungsi untuk mengubah text yang ada di variable billprint
             billprint.setText("===========================\n"+"Detail\n");
             //Mengisikan data belanjaan
             for (int i = 0; i < rowcount(); i++) {
                billprint.setText(billprint.getText() + Tabl.getValueAt(i, 0) + "\n");
                billprint.setText(billprint.getText() + Tabl.getValueAt(i, 1) + " x ");
                billprint.setText(billprint.getText() + Tabl.getValueAt(i, 2) + "\t\t ");
                billprint.setText(billprint.getText() + Tabl.getValueAt(i, 3) + "\n");
             }
             //Footer
             billprint.setText(
                     billprint.getText()+"\n+++++++++++++++++++++++++++\n"+
                     "\tTotal :\t"+Total.getText()+"\n"+
                     "\tBayar :\t"+Bayar.getText()+"\n"+
                     "\tKembali :\t"+
                     String.valueOf(Integer.valueOf(Bayar.getText()) - Integer.valueOf(Total.getText()))+
                     "\n"+
                     "\n========     Terima Kasih    ========="
             );
        }
        
        /**
           * Digunakan untuk menghitung ulang nilai total
        */
        public void counting(){
            int total=0;
            for(int i = 0; i < Tabl.getRowCount(); i++){
                total = total + (Integer)baca(i,3);
            }
            Total.setText(String.valueOf(total));
        }
        public void warning(String Text){
            Warn.setText(Text);
            jDialog2.setVisible(true);
        }
    }
    
    private void TambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TambahActionPerformed
        // TODO buat your handling code heresadfg
        //Inisialisasi Variable
        func func = new func();
        if ( jComboBox1.getSelectedItem() == null || Jumlah.getText().isEmpty()) {
            func.warning("Mohon isi nama beserta jumlahnya");
            Jumlah.requestFocus();
        }else{
            int jumlah,harga,totalnya;
            String nama = jComboBox1.getSelectedItem().toString();
            jumlah = Integer.valueOf(Jumlah.getText());
            harga = (int)func.Search(nama, 1, true);
            totalnya = harga*jumlah;
            //menjadikan object
            Object[] arr = new Object[]{nama,harga,jumlah,totalnya};
            func.buat(arr);
            func.counting();
        }
    }//GEN-LAST:event_TambahActionPerformed

    private void BersihActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BersihActionPerformed
        // TODO buat your handling code here:
        //Menginisialisasi table "Tabl"
        func func = new func();
        
        //menghapus detail yang ada
        jComboBox1.setSelectedItem(null);
        Jumlah.setText("");
        Total.setText("");
        Bayar.setText("");
        
        //Menghapus isi "Tabl"
        func.clear();
    }//GEN-LAST:event_BersihActionPerformed

    private void LihatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LihatActionPerformed
        // TODO buat your handling code here:
        // Mengalihkan Fokus ke class DataCore
        DataCore dt = TugasAkhir.dt;
        dt.setState(0);
        this.setState(1);
    }//GEN-LAST:event_LihatActionPerformed

    private void UbahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UbahActionPerformed
        // TODO buat your handling code here:
        //Inisialisasi Properti Variable
        func func = new func();
        if ( Tabl.getSelectedRow() == -1 || jComboBox1.getSelectedItem() == null || Jumlah.getText().isEmpty()) {
            func.warning("Mohon Memilih list ditable terlebih dahulu");
            Tabl.requestFocus();
        }else{
            int select = Tabl.getSelectedRow();
            String nama = jComboBox1.getSelectedItem().toString();
            Integer total,harga;

            //Inisialisasi Nilai berdasarkan isian pada masing masing kolom
            int qty = Integer.valueOf(Jumlah.getText());
            harga = (int)func.baca(select, 1);
            total = harga * qty;

            //Memberi Nilai kedalam table "Tabl"
            func.perbarui(nama, select, 0);
            func.perbarui(qty, select, 2);
            func.perbarui(total, select, 3);

            //Menghitung Ulang total
            func.counting();   
        }
    }//GEN-LAST:event_UbahActionPerformed
    
    private void OKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OKActionPerformed
        // TODO buat your handling code here:
        //Mengubah teks yang ada didalam jDialog1
        func func= new func();
        if(Bayar.getText().isEmpty()){
            if (!Total.getText().isEmpty()) {
                if (Integer.valueOf(Bayar.getText()) < Integer.valueOf(Total.getText())) {
                    func.warning("Maaf uang yang dibayar kurang");
                }
                func.warning("Maaf uang yang dibayar kurang");
            }
            Bayar.requestFocus();
        }else if(func.rowcount()<=0){
            func.warning("Maaf Anda Belum memilih untuk membeli");
        }
        else{
            func.printbill();
            //Memperlihatkan detail belanjaan yang ada di jDialog1
            jDialog1.setVisible(true);
        }
    }//GEN-LAST:event_OKActionPerformed

    private void HapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HapusActionPerformed
        // TODO buat your handling code here:
        //Menghapus baris yang telah dipilih
        func func=new func();
        if(Tabl.getSelectedRow() == -1){
            func.warning("Mohon memilih list tabel dulu");
            Tabl.requestFocus();
        }else{
            func.hapus(Tabl.getSelectedRow());
            //Menghitung Ulang total dan menulis ulang ke kolom total
            func.counting();
        }
    }//GEN-LAST:event_HapusActionPerformed

    private void TablMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TablMouseClicked
        // TODO buat your handling code here: 
        //Ketika User mengklik isi table maka kolom nama dan jumlah akan berubah sesuai dengan yang diklik
        func func = new func();
        int select = Tabl.getSelectedRow();
        jComboBox1.setSelectedItem(func.baca(select, 0));
        Jumlah.setText((String.valueOf(func.baca(select, 2))));
    }//GEN-LAST:event_TablMouseClicked

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jComboBox1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jComboBox1FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1FocusGained

    private void jComboBox1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBox1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1MouseClicked

    private void jComboBox1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBox1MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1MousePressed
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Bayar;
    private javax.swing.JButton Bersih;
    private javax.swing.JButton Hapus;
    private javax.swing.JTextField Jumlah;
    private javax.swing.JButton Lihat;
    private javax.swing.JButton OK;
    public javax.swing.JTable Tabl;
    private javax.swing.JButton Tambah;
    private javax.swing.JTextField Total;
    private javax.swing.JButton Ubah;
    private javax.swing.JTextArea Warn;
    private javax.swing.JTextArea billprint;
    public javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JDialog jDialog2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    // End of variables declaration//GEN-END:variables
}
